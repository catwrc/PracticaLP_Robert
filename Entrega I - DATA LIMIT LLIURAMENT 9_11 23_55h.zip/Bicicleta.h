#pragma once

#include <string>

#include "Data.h"


/**
* Enumeraciones necesarias para la creacion de bicicletas.
* Los valores son necesarios para poder realizar un control de errores eficiente.
* Si algun constructor recibe un parametro "ileagal" debeis establecer como valor por defecto
* el valor permitido mas peque�o del enum.
* 
**/

enum class TipusBicicleta
{
	INFANTIL = 100,
	MTB = 200,
	CARRETERA = 250
};

enum class Fre
{
	DISC = 0,
	RIM = 1,
};

enum class Quadre
{
	ALUMINI = 0,
	CARBONO = 1,
};

enum class Roda
{
	RODA_26 = 0,
	RODA_27 = 1,
	RODA_29 = 2,
	RODA_14 = 3,
	RODA_20 = 4,
	RODA_700 = 5,
};


enum class Talla
{
	XS = 0,
	S = 1,
	M = 2,
	L = 3,
	XL = 4,
};


/**
* Bicicleta es una clase que contiene toda la informacion relevante para definir una bicicleta generica.
* 
**/
class Bicicleta
{
public:
	virtual ~Bicicleta();
	
	string getModel() const;
	string getDescripcio() const;
	string getCodiRus() const;
	int getTemporada() const;
	Talla getTalla() const;
	Quadre getQuadre() const;
	Roda getRoda() const;
	Fre getFre() const;
	TipusBicicleta getTipus() const;
	Data getDataEntrada() const;
	virtual void setModel(const string& model) final;
	virtual void setDescripcio(const string& descripcio) final;
	virtual void setCodiRus(const string& codirus) final;
	virtual void setTemporada(const int& temporada) final;
	virtual void setTalla(const Talla& talla) final;
	virtual void setRoda(const Roda& roda);
	virtual void setQuadre(const Quadre& quadre);
	virtual void setFre(const Fre& fre);
	virtual void setTipus(TipusBicicleta tipus);
	virtual void setPreu(TipusBicicleta cost);
	virtual float getPreu() const;
	void setDataEntrada(Data d);

	bool operator<(const Bicicleta &b1) const;
	
protected:

};
